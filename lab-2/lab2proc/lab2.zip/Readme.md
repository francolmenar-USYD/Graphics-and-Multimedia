In order to execute it you just have to load the folder with processing and execute the file lab2proc
